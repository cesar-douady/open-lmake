#!/bin/bash
set -e
./build-all.py "$@"
