import simple2

m = {
    simple2.xxx.first: 1,
    simple2.xxx.second: 2,
    simple2.xxx.third: 3
}

v = m[ simple2.xxx.second ]
print( v )
