Version: 7.1.7 (13-Feb-2022)

Add support for building against python 3.11 alpha 4.

This Version 7.1.6 with README updates
