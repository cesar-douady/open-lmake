/* automatically generated - do not edit */
#ifndef _VERSION_H
#define _VERSION_H
#define VERSION_RELEASE "2.1.0"
#define VERSION_MAJOR 2
#define VERSION_MINOR 1
#define VERSION_MICRO 0
#endif
